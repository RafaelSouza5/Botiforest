const Discord = require('discord.js')

module.exports = {
    name: 'onrec',
    aliases: [''],


    run: async (client, message, args) => {
        
    }
}