module.exports = {
    app: {
        prefix: "!",
        token: "OTk0NjQ2ODMyMzY4MDcwNzY2.GG774d.aniU_-fV1BLHxp6lRbR_HZOOE9FMqEtJt1sW88",
        // playing: "✝ SHIRO ✝",
    },

    opt: {
        maxVol: 100,
        loopMessage: false,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
};